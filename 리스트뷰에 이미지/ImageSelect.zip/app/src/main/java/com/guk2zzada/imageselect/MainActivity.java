package com.guk2zzada.imageselect;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<DataList> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
    }

    public void onClick(View v) {
        new SelectImage().execute();
    }

    class SelectImage extends AsyncTask<String, String, String> {

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            try {
                JSONArray jsonArray = new JSONArray(values[0]);
                for(int n = 0; n < jsonArray.length(); n++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(n);
                    String fname = jsonObject.getString("fname");
                    String fimg = jsonObject.getString("partdata");
                    byte[] bImg = Base64.decode(fimg, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bImg, 0, bImg.length);
                    arrayList.add(new DataList(fname, bitmap));
                }

                FileAdapter adapter = new FileAdapter(getBaseContext(), R.layout.item, arrayList);
                listView.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            Request request = new Request.Builder()
                    .url("http://172.16.111.209:8081/MyWebServer/selectpart.jsp")
                    .build();

            OkHttpClient client = new OkHttpClient();
            client.newCall(request).enqueue(new MyResponse());
            return null;
        }

        class MyResponse implements Callback {

            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String strJSON = response.body().string();
                publishProgress(strJSON);
            }
        }
    }

    class FileAdapter extends ArrayAdapter<DataList> {

        Context context;
        int resource;
        ArrayList<DataList> arr;

        public FileAdapter(@NonNull Context context, int resource, @NonNull ArrayList<DataList> objects) {
            super(context, resource, objects);
            this.context = context;
            this.resource = resource;
            this.arr = objects;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View lay = convertView;

            if(lay == null) {
                lay = View.inflate(context, resource, null);
            }

            ImageView imgFood = lay.findViewById(R.id.imageView);
            TextView txtName = lay.findViewById(R.id.textView);

            imgFood.setImageBitmap(arr.get(position).file);
            txtName.setText(arr.get(position).name);

            return lay;
        }
    }

}

class DataList {
    String name;
    Bitmap file;

    DataList(String name, Bitmap file) {
        this.name = name;
        this.file = file;
    }
}