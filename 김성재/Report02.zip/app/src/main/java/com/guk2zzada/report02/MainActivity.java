package com.guk2zzada.report02;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, Dialog.OnClickListener {

    ListView listView;
    RelativeLayout lay;

    ArrayList<Actor> arr = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        ActorAdapter adapter = new ActorAdapter(this, R.layout.list_item, arr);
        listView.setAdapter(adapter);

    }

    public void onClick(View v) {
        lay = (RelativeLayout) View.inflate(this, R.layout.dialog_add, null);
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setView(lay);
        dialog.setTitle("입력 다이얼로그");
        dialog.setPositiveButton("확인", this);
        dialog.show();
    }

    @Override
    public void onClick(DialogInterface dialogInterface, int i) {
        EditText edtName = lay.findViewById(R.id.edtName);
        EditText edtCompany = lay.findViewById(R.id.edtCompany);

        String strName = edtName.getText().toString();
        String strCompany = edtCompany.getText().toString();

        arr.add(new Actor(strName, strCompany, R.drawable.nami));

    }
}

class ActorAdapter extends ArrayAdapter<Actor> {

    Context context;
    int resource;
    ArrayList<Actor> arr;
    RelativeLayout lay2;
    TextView txtResult;
    ImageView imageView;

    public ActorAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Actor> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.arr = objects;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View lay = convertView;

        if(lay == null) {
            lay = View.inflate(context, resource, null);
        }

        ImageView img = lay.findViewById(R.id.img);
        TextView txtName = lay.findViewById(R.id.txtName);
        TextView txtCompany = lay.findViewById(R.id.txtCompany);

        txtName.setText(arr.get(position).name);
        txtCompany.setText(arr.get(position).company);
        img.setImageResource(arr.get(position).image);

        lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lay2 = (RelativeLayout) View.inflate(context, R.layout.dialog_info, null);
                txtResult = lay2.findViewById(R.id.txtResult);
                imageView = lay2.findViewById(R.id.imageView);
                String strResult = "";
                strResult += "이름: " + arr.get(position).name + "\n";
                strResult += "소속사: " + arr.get(position).company;
                txtResult.setText(strResult);
                imageView.setImageResource(arr.get(position).image);
                AlertDialog.Builder dialog = new AlertDialog.Builder(context);
                dialog.setView(lay2);
                dialog.setTitle("입력 다이얼로그");
                dialog.setPositiveButton("확인", null);
                dialog.show();
            }
        });

        return lay;
    }
}

class Actor {
    String name;
    String company;
    int image;

    Actor(String name, String company, int image) {
        this.name = name;
        this.company = company;
        this.image = image;
    }
}