package com.example.smart.bserver;

import android.bluetooth.*;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    BluetoothAdapter mBA;
    DataBSocket dataBSocket;
    static final String  BLUE_NAME = "BluetoothEx";  // 접속시 사용하는 이름
    // 접속시 사용하는 고유 ID
    static final UUID BLUE_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
    EditText editText;
    TextView textView;
    ServerAsync serverAsync;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editText = (EditText) findViewById(R.id.editText);
        textView = (TextView) findViewById(R.id.textView);
        mBA = BluetoothAdapter.getDefaultAdapter();

       // setDiscoverable();
        serverAsync = new ServerAsync();
        serverAsync.execute();
    }

    public void setDiscoverable() {
        // 현재 검색 허용 상태라면 함수 탈출
        if( mBA.getScanMode() == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE )
            return;
        // 다른 디바이스에게 자신을 검색 허용 지정
        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 0);
        startActivity(intent);
    }

    public void onSend(View v)
    {

        dataBSocket.write(editText.getText().toString());
    }


    class ServerAsync extends AsyncTask<String, String, String>
    {
        private BluetoothServerSocket mmSSocket;
        BluetoothSocket cSocket = null;

        // 서버 소켓 생성
        public ServerAsync() {
            try {
                mmSSocket = mBA.listenUsingInsecureRfcommWithServiceRecord(BLUE_NAME, BLUE_UUID);
            } catch(IOException e) {
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            textView.setText("connected....");
            textView.setBackgroundColor(Color.RED);
            dataBSocket = new DataBSocket(cSocket);
            dataBSocket.execute();
        }

        @Override
        protected String doInBackground(String... params) {
            // 원격 디바이스에서 접속을 요청할 때까지 기다린다
            try {
                cSocket = mmSSocket.accept();
                publishProgress("connected.....");
            } catch(IOException e) {
                return null;
            }

            return null;
        }
    }
    class DataBSocket  extends AsyncTask<String, String, String>
    {
        private BluetoothSocket mmCSocket; // 클라이언트 소켓
        private InputStream mmInStream; // 입력 스트림
        private OutputStream mmOutStream; // 출력 스트림

        public DataBSocket(BluetoothSocket cSocket){
            this.mmCSocket = cSocket;
            try {
                mmInStream = mmCSocket.getInputStream();
                mmOutStream = mmCSocket.getOutputStream();
            } catch (IOException e) {
                Log.i("my", "1:" + e.getMessage());
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            textView.setText(values[0]);
        }

        @Override
        protected String doInBackground(String... params) {

            byte[] buffer = new byte[1024];
            int nbytes;
            while (true) {
                try {
                    // 입력 스트림에서 데이터를 읽는다
                    nbytes = mmInStream.read(buffer);
                    String strBuf = new String(buffer, 0, nbytes);
                    publishProgress(strBuf);
                    SystemClock.sleep(1);
                } catch (IOException e) {
                    Log.i("my", "1:"+e.getMessage());
                    break;
                }
            }

            return null;
        }

        public void write(String strBuf) {
            try {
                // 출력 스트림에 데이터를 저장한다
                byte[] buffer = strBuf.getBytes();
                mmOutStream.write(buffer);
            } catch (IOException e) {
                Log.i("my", "1:"+e.getMessage());
            }
        }
    }
}








