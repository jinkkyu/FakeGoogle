package com.guk2zzada.report04;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    MyAsyncTask myAsyncTask = new MyAsyncTask();
    ArrayList<DataList> arr = new ArrayList<>();
    DataAdapter adapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        adapter = new DataAdapter(this, R.layout.item_list, arr);
        listView.setAdapter(adapter);
        myAsyncTask.execute();

    }

    class MyAsyncTask extends AsyncTask<String, String, String> {

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected String doInBackground(String... strings) {
            String kURL = "http://web.kma.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=109";
            try {
                Document doc = Jsoup.connect(kURL).get();
                Elements loc = doc.select("location");
                for(int i = 0; i < loc.size(); i++) {
                    arr.add(new DataList(loc.get(i).select("city").text(), loc.get(i).toString()));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            adapter.notifyDataSetChanged();
        }
    }

    class DataAdapter extends ArrayAdapter<DataList> {

        Context context;
        int resource;
        ArrayList<DataList> arr;

        public DataAdapter(@NonNull Context context, int resource, @NonNull ArrayList<DataList> objects) {
            super(context, resource, objects);
            this.context = context;
            this.resource = resource;
            this.arr = objects;
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View lay = convertView;

            if(lay == null) {
                lay = View.inflate(context, resource, null);
            }

            TextView textView = lay.findViewById(R.id.textView);
            textView.setText(arr.get(position).city);

            lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getBaseContext(), ResultActivity.class);
                    intent.putExtra("elements", arr.get(position).detail);
                    startActivity(intent);

                }
            });

            return lay;
        }
    }
}

class DataList {
    String city;
    String detail;

    DataList(String city, String detail) {
        this.city = city;
        this.detail = detail;
    }
}