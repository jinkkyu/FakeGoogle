package com.guk2zzada.report04;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    ArrayList<DataDetail> arr = new ArrayList<>();
    DataAdapter adapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        listView = findViewById(R.id.listView);

        Intent intent = getIntent();
        String str = intent.getStringExtra("elements");
        Document doc = Jsoup.parse(str);
        Elements elements = doc.select("data");
        for(Element element : elements) {
            arr.add(new DataDetail(element.select("tmEf").text(), element.select("tmn").text(), element.select("wf").text()));
        }

        adapter = new DataAdapter(this, R.layout.item_detail, arr);
        listView.setAdapter(adapter);

    }

    class DataAdapter extends ArrayAdapter<DataDetail> {

        Context context;
        int resource;
        ArrayList<DataDetail> arr;

        public DataAdapter(@NonNull Context context, int resource, @NonNull ArrayList<DataDetail> objects) {
            super(context, resource, objects);
            this.context = context;
            this.resource = resource;
            this.arr = objects;
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View lay = convertView;

            if(lay == null) {
                lay = View.inflate(context, resource, null);
            }

            TextView textView = lay.findViewById(R.id.textView);
            TextView textView2 = lay.findViewById(R.id.textView2);
            textView.setText(arr.get(position).date);
            textView2.setText(arr.get(position).min);
            ImageView imageView = lay.findViewById(R.id.imageView);

            int drawable = R.drawable.sun;

            switch(arr.get(position).weather) {
                case "맑음":
                    drawable = R.drawable.sun;
                    break;

                case "흐리고 비":
                    drawable = R.drawable.suncloudrain;
                    break;

                case "흐리고 눈":
                    drawable = R.drawable.suncloudsnow;
                    break;

                case "구름조금":
                    drawable = R.drawable.cloudsun;
                    break;

                case "구름많음":
                    drawable = R.drawable.suncloudy;
                    break;

                case "구름많고 비/눈":
                    drawable = R.drawable.suncloudrainsnow;
                    break;

                default:
                    drawable = R.drawable.sun;
                    break;
            }

            imageView.setImageResource(drawable);

            return lay;
        }
    }
}

class DataDetail {
    String date;
    String min;
    String weather;

    DataDetail(String date, String min, String weather) {
        this.date = date;
        this.min = min;
        this.weather = weather;
    }
}