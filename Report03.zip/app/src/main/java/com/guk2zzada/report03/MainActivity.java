package com.guk2zzada.report03;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnStart;
    Button btnStop;
    MyView myView;
    MyHandler myHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        myView = findViewById(R.id.myView2);

        myHandler = new MyHandler(myView);
    }

    public void startMove(View v) {
        myHandler.sendEmptyMessage(0);
    }

    public void stopMove(View v) {
        myHandler.removeMessages(0);
    }
}

class MyHandler extends Handler {

    MyView myView;

    public MyHandler(MyView view) {
        myView = view;
    }

    @Override
    public void handleMessage(Message msg) {
        myView.moveBall(20);
        sendEmptyMessageDelayed(0, 10);

        super.handleMessage(msg);
    }
}
