package com.guk2zzada.report03;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/**
 * Created by user on 2018-01-10.
 */

public class MyView extends View {
    float nX = 300;
    float nY = 300;

    int nColor;
    boolean boolRight = true;
    boolean boolBottom = true;

    public MyView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray attr = context.getTheme().obtainStyledAttributes(attrs, R.styleable.MyView, 0, 0);
        nX = attr.getFloat(R.styleable.MyView_nX, 0);
        nY = attr.getFloat(R.styleable.MyView_nY, 0);
        nColor = attr.getColor(R.styleable.MyView_myColor, Color.RED);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(nColor);
        //canvas.drawRect(10, 10, 10, 10, paint);
        canvas.drawCircle(nX, nY, 100, paint);
        super.onDraw(canvas);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Toast.makeText(getContext(), "call", Toast.LENGTH_SHORT).show();
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        nX = event.getX();
        nY = event.getY();

        invalidate();

        //Toast.makeText(this, "x: " + nX + " y: " + nY, Toast.LENGTH_SHORT).show();

        return super.onTouchEvent(event);
    }

    public void setColor(int color) {
        nColor = color;
        invalidate();
    }

    public void moveBall(int speed) {

        if(boolRight) {
            nX = nX + speed;
        } else {
            nX = nX - speed;
        }

        if(nX > getWidth() - 100) {
            boolRight = false;
        } else if(nX < 100) {
            boolRight = true;
        }

        invalidate();
    }
}
