package kr.co.company.bluetoothtest;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

import android.annotation.TargetApi;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class BluetoothTestActivity extends Activity implements AdapterView.OnItemClickListener
{

   String address;
   static final UUID BLUE_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");

   private static final UUID MY_UUID_SECURE =
           UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
   private static final UUID MY_UUID_INSECURE =
           UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");

   BluetoothSocket mmCSocket;

   private Button list;
   private BluetoothAdapter mBluetoothAdapter;
   private Set<BluetoothDevice>pairedDevices;
   private ListView lv;
   FindBDevice findBDevice;
   ArrayList arrlist = new ArrayList();
   ArrayAdapter adapter;
   EditText editText;
   DataBluetoothRecv recvData;
   TextView textRecv;
   TextView textViewState;


   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.main);

      textRecv = (TextView) findViewById(R.id.textViewRecive);
      list = (Button)findViewById(R.id.button4);
      lv = (ListView)findViewById(R.id.listView);
      lv.setOnItemClickListener(this);
      editText = (EditText) findViewById(R.id.editText);
      textViewState = (TextView) findViewById(R.id.textViewState);

      mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
      findBDevice = new FindBDevice();

      adapter = new ArrayAdapter

              (this, android.R.layout.simple_list_item_1);
      lv.setAdapter(adapter);

   }

   public void on(View view){
      if (!mBluetoothAdapter.isEnabled()) {
         Intent turnOn = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
         startActivityForResult(turnOn, 0);
         Toast.makeText(getApplicationContext(),"enabel."
         ,Toast.LENGTH_LONG).show();
      }
      else{
         Toast.makeText(getApplicationContext(),"already..",
         Toast.LENGTH_LONG).show();
         }
   }
   public void list(View view){
      pairedDevices = mBluetoothAdapter.getBondedDevices();

      ArrayList list = new ArrayList();
      for(BluetoothDevice bt : pairedDevices)
         list.add(bt.getName());

      Toast.makeText(getApplicationContext(),"bonded list.",
      Toast.LENGTH_SHORT).show();
      final ArrayAdapter adapter = new ArrayAdapter
      (this,android.R.layout.simple_list_item_1, list);
      lv.setAdapter(adapter);

   }
   public void off(View view){
      mBluetoothAdapter.disable();
      Toast.makeText(getApplicationContext(),"blutooth off." ,
      Toast.LENGTH_LONG).show();
   }
   public void visible(View view){
//      Intent getVisible = new Intent(BluetoothAdapter.
//      ACTION_REQUEST_DISCOVERABLE);
//      startActivityForResult(getVisible, 0);

      if( mBluetoothAdapter.getScanMode() == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE )
         return;
      // 다른 디바이스에게 자신을 검색 허용 지정
      Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
      intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 0);
      startActivity(intent);

   }
   public void onSearch(View view)
   {
      mBluetoothAdapter.startDiscovery();
      // 원격 디바이스 검색 이벤트 리시버 등록
      registerReceiver(findBDevice, new IntentFilter(BluetoothDevice.ACTION_FOUND));
   }

   public void stopFindDevice() {
      // 현재 디바이스 검색 중이라면 취소한다
      if( mBluetoothAdapter.isDiscovering() )
      {
         mBluetoothAdapter.cancelDiscovery();
         // 브로드캐스트 리시버를 등록 해제한다
         unregisterReceiver(findBDevice);
      }
   }



   public void onConnect(View v)
   {
      try {
         BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);

         if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD_MR1)
         {
            mmCSocket = device.createInsecureRfcommSocketToServiceRecord(BLUE_UUID);
         }

         mmCSocket.connect();
         recvData = new DataBluetoothRecv();
         recvData.execute();
         Toast.makeText(this, "connect", Toast.LENGTH_SHORT).show();
         textViewState.setText("접속됨...");
         textViewState.setBackgroundColor(Color.RED);
      }catch (Exception ex)
      {
         Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
      }
   }

   public void onSend(View v)
   {
      recvData.write( editText.getText().toString() );
   }


   @Override
   protected void onDestroy() {
      stopFindDevice();
      super.onDestroy();
   }


   @Override
   public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

      String strItem = (String) adapter.getItem(position);
      // 사용자가 선택한 디바이스의 주소를 구한다
      int pos = strItem.indexOf("-");
      address = strItem.substring(pos+1);
      editText.setText("Sel Device: " + address);
      // 디바이스 검색 중지
      stopFindDevice();
   }


   class DataBluetoothRecv extends AsyncTask<String,String, String>
   {
      private InputStream mmInStream; // 입력 스트림
      private OutputStream mmOutStream; // 출력 스트림

      public DataBluetoothRecv() {
         // 입력 스트림과 출력 스트림을 구한다
         try {
            mmInStream = mmCSocket.getInputStream();
            mmOutStream = mmCSocket.getOutputStream();
         } catch (IOException e) {
            Log.i("my", "1:"+e.getMessage());
         }
      }

      @Override
      protected void onProgressUpdate(String... values) {
         textRecv.setText(values[0] );
      }

      @Override
      protected String doInBackground(String... params) {
         byte[] buffer = new byte[1024];
         int nbytes;
         while (true) {
            try {
               // 입력 스트림에서 데이터를 읽는다
               nbytes = mmInStream.read(buffer);
               String strBuf = new String(buffer, 0, nbytes);
               publishProgress(strBuf);
               SystemClock.sleep(1);
            } catch (IOException e) {
               Log.i("my", "1:"+e.getMessage());
               break;
            }
         }

         return null;
      }
      public void write(String strBuf) {
         try {
            // 출력 스트림에 데이터를 저장한다
            byte[] buffer = strBuf.getBytes();
            mmOutStream.write(buffer);
         } catch (IOException e) {
            Log.i("my", "1:"+e.getMessage());
         }
      }
   }

   class FindBDevice extends BroadcastReceiver
   {
      @Override
      public void onReceive(Context context, Intent intent) {

         String action = intent.getAction();
         if(action==BluetoothAdapter.ACTION_DISCOVERY_STARTED) {
            Toast.makeText(getBaseContext(), "블루투스 검색 시작", Toast.LENGTH_SHORT).show();
         }
         else if( action==BluetoothDevice.ACTION_FOUND) {
            //검색한 블루투스 디바이스의 객체를 구한다
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            adapter.add(device.getName() + "-" + device.getAddress());


         }else if(action==BluetoothAdapter.ACTION_DISCOVERY_FINISHED){
            //블루투스 디바이스 검색 종료
            Toast.makeText(getBaseContext(), "블루투스 검색 종료", Toast.LENGTH_SHORT).show();
         }

//         Toast.makeText(getBaseContext(), "call...", Toast.LENGTH_SHORT).show();
//         if( intent.getAction() == BluetoothDevice.ACTION_FOUND )
//         {
//
//            // 인텐트에서 디바이스 정보 추출
//            BluetoothDevice device = intent.getParcelableExtra( BluetoothDevice.EXTRA_DEVICE );
//            // 페어링된 디바이스가 아니라면
////            if( device.getBondState() != BluetoothDevice.BOND_BONDED )
//               // 디바이스를 목록에 추가
////            addDeviceToList(device.getName(), device.getAddress());
//            adapter.add(device.getName()+"-"+device.getAddress());
//
//
//         }

      }
   }

}


